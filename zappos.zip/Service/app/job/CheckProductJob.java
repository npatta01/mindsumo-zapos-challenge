package job;

import com.google.inject.Inject;
import email.IEmailService;
import email.MailParams;
import model.ProductWithStyle;
import model.VerificationEnum;
import registration.RegistrationService;
import serviceclient.notification.NotificationService;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * A Task to check Zappos for existing price items
 */
public class CheckProductJob implements Runnable {
    public static final double SaleConstant = 0.20;
    //registration service
    private RegistrationService rs;
    //notification service
    private NotificationService ns;
    //email service
    private IEmailService iEmailService;

    /**
     * Constructor for new job
     * @param rs              registration service
     * @param ns                                  notification service
     * @param iEmailService                                           email service
     */
    @Inject
    public CheckProductJob(RegistrationService rs, NotificationService ns, IEmailService iEmailService) {
        this.rs = rs;
        this.ns = ns;
        this.iEmailService = iEmailService;
    }

    /**
     * Ruun
     */
    @Override
    public void run() {
        //get items on sale
        ArrayList<ProductWithStyle> itemsonsale = getProductsThatOnSale();
        //convert items on sale, to User->items on sale
        HashMap<String, List<ProductWithStyle>> notificationList = getListOfUserToNotify(itemsonsale);

        //send email to user with a list of items on that that they subscribed to
        for (String s : notificationList.keySet()) {
            MailParams mailParamsForUser = rs.getMailParamsForUser(s);
            mailParamsForUser.items = notificationList.get(s);
            iEmailService.sendNotificationEmail(mailParamsForUser);
        }
    }

    /**
     * For the items on sale, get the users interested in the item
     * @param itemsonsale          items on sale
     * @return    User->product mapping
     */
    private HashMap<String, List<ProductWithStyle>> getListOfUserToNotify(ArrayList<ProductWithStyle> itemsonsale) {
        //User->product ids
        HashMap<String, List<ProductWithStyle>> notificationList = new HashMap<>();
        //for each product on sale
        for (ProductWithStyle p : itemsonsale) {
            String[] subscribedUsers = rs.getSubscribedUsers(p.styleId);
            //for each subscribed user of this product
            for (String s : subscribedUsers) {
                if (rs.verifyUser(s, null) == VerificationEnum.ALREADY_VERIFIED) {
                    if (notificationList.containsKey(s)) {
                        notificationList.get(s).add(p);
                    } else {
                        ArrayList<ProductWithStyle> productWithStyles = new ArrayList<>();
                        productWithStyles.add(p);
                        notificationList.put(s, productWithStyles);
                    }
                }
            }
        }
        return notificationList;
    }

    /**
     * Get list of items on sale
     * @return items on sale
     */
    private ArrayList<ProductWithStyle> getProductsThatOnSale() {
        //items that all users are interested in being notified
        Long[] allSubscribedItems = rs.getAllSubscribedItems();
        ArrayList<ProductWithStyle> itemsonsale = new ArrayList<>();
        for (Long l : allSubscribedItems) {
            try {
                //check if on sale
                ProductWithStyle[] productByStyleId = ns.getProductByStyleId(String.valueOf(l));
                if (productByStyleId[0].percentOff >= SaleConstant) {
                    itemsonsale.add(productByStyleId[0]);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return itemsonsale;
    }
}