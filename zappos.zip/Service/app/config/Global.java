package config;
import com.google.inject.Guice;
import com.google.inject.Injector;
import email.IEmailService;
import job.CheckProductJob;
import play.Application;
import play.GlobalSettings;
import play.libs.Akka;
import registration.RegistrationService;
import scala.concurrent.duration.Duration;
import serviceclient.notification.NotificationService;

import java.util.concurrent.TimeUnit;

/**
 * Main Entry point for the play application
 */
public class Global extends GlobalSettings {
    //injector used to load controller
    private Injector INJECTOR;

    /**
     * Get instance of controller with dependencies already set
     * @param controllerClass   Class of controller
     * @param <A>   Type
     * @return          Instance of controller class
     * @throws Exception
     */
    @Override
    public <A> A getControllerInstance(Class<A> controllerClass) throws Exception {
        return INJECTOR.getInstance(controllerClass);
    }

    /**
     * OnStart of the play app
     * @param app
     */
    @Override
    public void onStart(Application app) {
        //reference to current hostname; its HARDCODED :(
        String BASE_URL = app.configuration().getString("service.url");
        //initialize the injector
        INJECTOR = Guice.createInjector(new ServiceModule(BASE_URL));
        schedulePriceCheckJob();
    }

    /**
     * Schedule the Zappos Price Check Job to run every 12 hours since server launch
     */
    private void schedulePriceCheckJob() {
        RegistrationService rs = INJECTOR.getInstance(RegistrationService.class);
        IEmailService ies = INJECTOR.getInstance(IEmailService.class);
        NotificationService ns = INJECTOR.getInstance(NotificationService.class);
        Akka.system().scheduler().schedule(Duration.create(10, TimeUnit.MINUTES), Duration.create(12, TimeUnit.HOURS), new CheckProductJob(rs, ns, ies), Akka.system().dispatcher());
    }
}
