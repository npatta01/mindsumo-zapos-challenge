package config;

import com.google.inject.AbstractModule;
import com.google.inject.Scopes;
import controllers.Application;
import controllers.EmailService;
import controllers.ProductController;
import controllers.UserController;
import email.IEmailService;
import registration.RegistrationService;
import registration.UserDatabase;
import serviceclient.zappos.ZapposClient;

/**
 * Module defining dependenices for the Play ervice
 */
public class ServiceModule extends AbstractModule {
    //url of localhost
    private String Base_URL;

    /**
     * Constructor
     * @param Base_URL hostname
     */
    public ServiceModule(String Base_URL) {
        this.Base_URL = Base_URL;
    }

    /**
     * Define dependencies
     */
    @Override
    protected void configure() {
        ServerConfig sc = new ServerConfig(Base_URL);
        bind(ServerConfig.class).toInstance(sc);
        bind(UserDatabase.class).in(Scopes.SINGLETON);
        bind(ZapposClient.class).in(Scopes.SINGLETON);
        bind(RegistrationService.class).in(Scopes.SINGLETON);
        bind(IEmailService.class).to(EmailService.class).in(Scopes.SINGLETON);
        bind(UserController.class);
        bind(ProductController.class);
        bind(Application.class);
    }
}
