package controllers;

import com.google.inject.Inject;
import model.ProductWithStyle;
import model.VerificationEnum;
import model.VoidResponse;
import org.codehaus.jackson.JsonNode;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Result;
import registration.RegistrationService;
import serviceclient.notification.SubscriptionRequest;
import serviceclient.zappos.SearchResponse;
import serviceclient.zappos.ZapposApiException;
import serviceclient.zappos.ZapposClient;

import java.util.ArrayList;

/**
 * Controller for routes /api/User
 * Get info on a user
 */
public class UserController extends Controller {
    @Inject
    private RegistrationService registrationService;
    @Inject
    private ZapposClient zapposService;

    /**
     * Remvoe user from system
     *
     * @param email email address
     * @return status of weather user existed/removed
     */
    @BodyParser.Of(BodyParser.Json.class)
    public Result unregister(String email) {
        VerificationEnum verificationEnum = registrationService.unSubscribeAll(email);
        VoidResponse vr = new VoidResponse();
        vr.message = verificationEnum.toString();
        vr.statusCode = 200;
        return ok(Json.toJson(vr));
    }

    /**
     * Register user in system. If user exists, retrieve subscriptions
     *
     * @param email email
     * @return User subscriptions
     */
    @BodyParser.Of(BodyParser.Json.class)
    public Result register(String email) {
        SearchResponse productWithStyleResponse = new SearchResponse();
        productWithStyleResponse.statusCode = 200;
        //if existing user
        if (registrationService.userExists(email)) {
            Long[] subscribedItems = registrationService.getSubscribedItems(email);
            ArrayList<ProductWithStyle> pws = new ArrayList<>();
            for (long styleId : subscribedItems) {
                try {
                    ProductWithStyle p = zapposService.getProductByStyleId(styleId)[0];
                    pws.add(p);
                } catch (ZapposApiException zae) {
                    zae.printStackTrace();
                }
            }
            productWithStyleResponse.results = pws.toArray(new ProductWithStyle[pws.size()]);
        } else {  //new user
            registrationService.register(email);
        }
        return ok(Json.toJson(productWithStyleResponse));
    }

    /**
     * Register user to be notified for item
     * Body must match POJO: SearchResponse{"email":"", "products":[styledid,styleid2}
     *
     * @return void
     */
    @BodyParser.Of(BodyParser.Json.class)
    public Result notifyForItem() {
        JsonNode json = request().body().asJson();
        //verify if required fields
        if (json == null) {
            return badRequest("Expecting Json data");
        }
        SubscriptionRequest sr = Json.fromJson(json, SubscriptionRequest.class);
        if (sr.emailAddress.isEmpty()) {
            return badRequest("Missing parameter [emailAddress]");
        }
        //if user exists,update subscriptions
        if (registrationService.userExists(sr.emailAddress)) {
            if (sr.products == null) {
                return badRequest("Missing parameter [prodcuts]");
            }
            registrationService.subscribe(sr.emailAddress, sr.products);
            VoidResponse vr = new VoidResponse();
            vr.statusCode = 200;
            vr.message = "Subscribed to " + sr.products.length + " items";
            return ok(Json.toJson(vr));
        } else {
            return badRequest("User does not exist");
        }
    }

    /**
     * Unregister the user for the passed set of items
     * Body must match POJO: SearchResponse{"email":"", "products":[styledid,styleid2}
     * @return      void
     */
    @BodyParser.Of(BodyParser.Json.class)
    public Result unnotifyForItem() {
        //verify parameters
        JsonNode json = request().body().asJson();
        if (json == null) {
            return badRequest("Expecting Json data");
        }
        SubscriptionRequest sr = Json.fromJson(json, SubscriptionRequest.class);
        if (sr.emailAddress.isEmpty()) {
            return badRequest("Missing parameter [emailAddress]");
        }

        //if user exists, update notification
        if (registrationService.userExists(sr.emailAddress)) {
            if (sr.products == null) {
                return badRequest("Missing parameter [products]");
            }
            registrationService.unSubscribe(sr.emailAddress, sr.products);
            VoidResponse vr = new VoidResponse();
            vr.statusCode = 200;
            vr.message = " Unsubscribed to " + sr.products.length + " items";
            return ok(Json.toJson(vr));
        } else {
            return badRequest("User does not exist");
        }
    }

    /**
     * Verify if user is owner of email
     *
     * @param email            email address
     * @param verificationCode uuid verification code
     * @return status of verification
     */
    @BodyParser.Of(BodyParser.Json.class)
    public Result verify(String email, String verificationCode) {
        VerificationEnum verificationEnum = registrationService.verifyUser(email, verificationCode);
        VoidResponse vr = new VoidResponse();
        vr.statusCode = 200;
        vr.message = verificationEnum.toString();
        return ok(Json.toJson(vr));
    }
}
