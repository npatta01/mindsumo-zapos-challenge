package controllers;

import email.IEmailService;
import email.MailParams;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;
import views.html.priceDropBody;
import views.html.welcomEmail;

/**
 * Implementation of an email service
 */
public class EmailService implements IEmailService {
    /**
     * Send email with the given parmams using the local smtp server
     *
     * @param mp      mail params
     * @param body    body of email
     * @param subject subject of email
     */
    private void sendEmail(MailParams mp, String body, String subject) {
        String host = play.Play.application().configuration().getString("smtp.host");
        String uName = play.Play.application().configuration().getString("smtp.user");
        String password = play.Play.application().configuration().getString("smtp.pass");
        int port = play.Play.application().configuration().getInt("smtp.port");
        HtmlEmail email = new HtmlEmail();
        email.setAuthentication(uName, password);
        email.setSmtpPort(port);
        email.setSubject(subject);
        try {
            email.setHostName(host);
            email.setFrom(mp.fromEmail);
            email.addTo(mp.toEmail);
            email.setHtmlMsg(body);
            email.setSSL(true);
            email.setDebug(true);
            email.send();
        } catch (EmailException e) {
            e.printStackTrace();
        }
    }

    /**
     * Send welcome email
     * @param mp  Parameters to send
     */
    @Override
    public void sendWelcomeEmail(MailParams mp) {
        String body = welcomEmail.render(mp).body();
        sendEmail(mp, body, "Verify Zappos Notification Subscription");
    }

    /**
     * Send Price update email
     * @param mp  mail params
     */
    @Override
    public void sendNotificationEmail(MailParams mp) {
        String body = priceDropBody.render(mp).body();
        sendEmail(mp, body, "Zappos Items on sale!!!");
    }
}
