package controllers;

import com.google.inject.Inject;
import email.IEmailService;
import job.CheckProductJob;
import play.libs.Akka;
import play.mvc.Controller;
import play.mvc.Result;
import registration.RegistrationService;
import scala.concurrent.duration.Duration;
import serviceclient.notification.NotificationService;

import java.util.concurrent.TimeUnit;

/**
 * Controller for Administrative tasks
 */
public class Application extends Controller {
    //registration service
    @Inject
    RegistrationService rs;
    //notification service
    @Inject
    NotificationService ns;
    //email service
    @Inject
    IEmailService iEmailService;

    /**
     * Forcefully launch the price check job
     * @return  void
     */
    public Result forceStartNotificationJob() {
        Akka.system().scheduler().scheduleOnce(Duration.create(0, TimeUnit.MINUTES), new CheckProductJob(rs, ns, iEmailService), Akka.system().dispatcher());
        return ok("Launched Zappos Price Check Job");
    }
}
