package controllers;

import com.google.inject.Inject;
import model.ProductWithStyle;
import model.VoidResponse;
import play.cache.Cache;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Result;
import serviceclient.zappos.SearchResponse;
import serviceclient.zappos.ZapposApiException;
import serviceclient.zappos.ZapposClient;

/**
 * Controller for the product resource.
 * Get product by style id, product name and product
 */
public class ProductController extends Controller {
    //reference to zappos client
    @Inject
    private ZapposClient zapposService;

    /**
     * Get Product using either query param product_id,style_id,product_name
     *
     * @return json result
     */
    @BodyParser.Of(BodyParser.Json.class)
    public Result getProduct() {
        String product_id = request().getQueryString("product_id");
        if (product_id != null) {
            return getProductById(Long.parseLong(product_id));
        }
        String style_id = request().getQueryString("style_id");
        if (style_id != null) {
            return getProductByStyleId(Long.parseLong(style_id));
        }
        String productName = request().getQueryString("product_name");
        if (productName != null) {
            return getProductByProductName(productName);
        }
        return badRequest("Must contain product_id|product_name_|style_id ");
    }

    /**
     * Get product using product id
     *
     * @param id product id
     * @return json encoding of results
     */
    @BodyParser.Of(BodyParser.Json.class)
    public Result getProductById(Long id) {
        //retrieve from cache
        String cacheKey = "product_id_" + id;
        ProductWithStyle[] ps = (ProductWithStyle[]) Cache.get(cacheKey);
        SearchResponse resp = new SearchResponse();
        if (ps == null) {
            try {
                ps = zapposService.getProductById(id);
                Cache.set(cacheKey, ps);
                resp.statusCode = 200;
                resp.results = ps;
            } catch (ZapposApiException e) {
                VoidResponse vr = new VoidResponse();
                vr.statusCode = 500;
                vr.message = e.getLocalizedMessage();
                return ok(Json.toJson(vr));
            }
        } else {
            resp.statusCode = 200;
            resp.results = ps;
        }
        return ok(Json.toJson(resp));
    }

    /**
     * Get product by style id
     *
     * @param id style id
     * @return      json encoding of results
     */
    @BodyParser.Of(BodyParser.Json.class)
    public Result getProductByStyleId(Long id) {
        String cacheKey = "style_id_" + id;
        ProductWithStyle[] ps = (ProductWithStyle[]) Cache.get(cacheKey);
        SearchResponse resp = new SearchResponse();
        if (ps == null) {
            try {
                ps = zapposService.getProductByStyleId(id);
                Cache.set(cacheKey, ps);
                resp.statusCode = 200;
                resp.results = ps;
            } catch (ZapposApiException e) {
                VoidResponse vr = new VoidResponse();
                vr.statusCode = 500;
                vr.message = e.getLocalizedMessage();
                return ok(Json.toJson(vr));
            }
        } else {
            resp.statusCode = 200;
            resp.results = ps;
        }
        return ok(Json.toJson(resp));
    }

    /**
     * Get product by name
     * @param productName product name
     * @return    json encoding of results
     */
    @BodyParser.Of(BodyParser.Json.class)
    public Result getProductByProductName(String productName) {
        String cacheKey = "product_name_" + productName;
        ProductWithStyle[] ps = (ProductWithStyle[]) Cache.get(cacheKey);
        SearchResponse resp = new SearchResponse();
        if (ps == null) {
            try {
                ps = zapposService.getProductByName(productName);
                Cache.set(cacheKey, ps);
                resp.statusCode = 200;
                resp.results = ps;
            } catch (ZapposApiException e) {
                VoidResponse vr = new VoidResponse();
                vr.statusCode = 500;
                vr.message = e.getLocalizedMessage();
                return ok(Json.toJson(vr));
            }
        } else {
            resp.statusCode = 200;
            resp.results = ps;
        }
        return ok(Json.toJson(resp));
    }
}
