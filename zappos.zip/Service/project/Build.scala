import sbt._
import Keys._
import play.Project._

object ApplicationBuild extends Build {

  val appName         = "Service"
  val appVersion      = "1.0-SNAPSHOT"

  val appDependencies = Seq(
    // Add your project dependencies here,
    javaCore,
    javaJdbc,
    javaEbean,
   "mysql" % "mysql-connector-java" % "5.1.21", jdbc, anorm,
  "com.typesafe" %% "play-plugins-mailer" % "2.1-RC2",
  "com.google.inject" % "guice" % "3.0"

  )

  val main = play.Project(appName, appVersion, appDependencies).settings(
    // Add your own project settings here
    // Add your own project settings here
    testOptions in Test += Tests.Argument("junitxml", "console")
  )

}
