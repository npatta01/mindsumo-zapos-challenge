package serviceclient.zappos;

import model.Product;

/**
 * Zappos Product Response
 */
public class ProductResponse {
    //product
    public Product []product;
    //status code
    public int statusCode;
}
