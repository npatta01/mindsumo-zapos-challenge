package model;

/**
 * Generic Response
 */
public class VoidResponse {
   //status code
    public int statusCode;
    //message
    public String message;
}
